package Tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.Inventorypage;
import pages.SidebarMenu;

public class SidebarMenuTest extends BaseTest {

    @Test(priority = 1, description = "SM-001: Verify sidebar menu can be opened and closed")
    public void testMenuOpenClose() {
        Inventorypage inventoryPage = new Inventorypage(driver);
        SidebarMenu sidebarMenu = new SidebarMenu(driver);

        // Test opening menu
        inventoryPage.openMenu();
        Assert.assertTrue(sidebarMenu.isMenuDisplayed(), "Menu should be displayed after clicking menu button");

        // Test closing menu
        sidebarMenu.closeMenu();
        Assert.assertFalse(sidebarMenu.isMenuDisplayed(), "Menu should be hidden after clicking close button");
    }

    @Test(priority = 2, description = "SM-002: Verify all menu items are present")
    public void testMenuItemsPresence() {
        Inventorypage inventoryPage = new Inventorypage(driver);
        SidebarMenu sidebarMenu = new SidebarMenu(driver);

        inventoryPage.openMenu();

        Assert.assertTrue(sidebarMenu.isAllItemsLinkDisplayed(), "All Items link should be present");
        Assert.assertTrue(sidebarMenu.isAboutLinkDisplayed(), "About link should be present");
        Assert.assertTrue(sidebarMenu.isLogoutLinkDisplayed(), "Logout link should be present");
        Assert.assertTrue(sidebarMenu.isResetAppStateLinkDisplayed(), "Reset App State link should be present");
    }

    @Test(priority = 3, description = "SM-003: Test About link navigation")
    public void testAboutLink() {
        Inventorypage inventoryPage = new Inventorypage(driver);
        SidebarMenu sidebarMenu = new SidebarMenu(driver);

        inventoryPage.openMenu();
        sidebarMenu.clickAbout();

        Assert.assertTrue(driver.getCurrentUrl().contains("saucelabs.com"),
                "Should navigate to Sauce Labs website");

        // Return to inventory page for next tests
        driver.navigate().back();
    }
}

